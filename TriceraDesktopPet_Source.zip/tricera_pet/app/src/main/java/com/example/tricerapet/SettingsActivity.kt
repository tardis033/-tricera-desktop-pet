package com.example.tricerapet

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PetService.PREFS, MODE_PRIVATE) }
    private val density by lazy { resources.displayMetrics.density }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)); setBackgroundColor(0xFFFFF8F2.toInt()) }
        root.addView(TextView(this).apply { text = "个性化设置"; textSize = 25f; setTextColor(0xFF30221E.toInt()) })
        root.addView(TextView(this).apply { text = "只调整显示和行为，不修改角色原图。"; textSize = 14f; setPadding(0, dp(6), 0, dp(18)); setTextColor(0xFF74645D.toInt()) })
        addSlider(root, "角色大小", 80, 220, prefs.getInt("size", 150), "size", "${'$'}v%", 150)
        addSlider(root, "透明度", 35, 100, prefs.getInt("alpha", 100), "alpha", "${'$'}v%", 100)
        addSlider(root, "无操作后休息时间", 15, 180, prefs.getInt("idle", 60), "idle", "${'$'}v 秒", 60)
        root.addView(Switch(this).apply {
            text = "启用轻微动画"
            textSize = 16f
            isChecked = prefs.getBoolean("animation", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("animation", checked).apply(); PetService.notifySettingsChanged(this@SettingsActivity) }
        }, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(Switch(this).apply {
            text = "允许触摸唤醒"
            textSize = 16f
            isChecked = prefs.getBoolean("touchWake", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("touchWake", checked).apply(); PetService.notifySettingsChanged(this@SettingsActivity) }
        }, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(Button(this).apply { text = "完成"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun addSlider(root: LinearLayout, title: String, min: Int, max: Int, current: Int, key: String, suffix: String, default: Int) {
        val label = TextView(this).apply { textSize = 16f; setTextColor(0xFF30221E.toInt()) }
        fun display(v: Int) { label.text = "$title：${suffix.replace("${'$'}v", v.toString())}" }
        display(current)
        root.addView(label)
        root.addView(SeekBar(this).apply {
            this.max = max - min
            progress = current.coerceIn(min, max) - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min; display(v); if (fromUser) { prefs.edit().putInt(key, v).apply(); PetService.notifySettingsChanged(this@SettingsActivity) }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(Space(this), LinearLayout.LayoutParams(1, dp(8)))
    }
    private fun dp(v: Int) = (v * density).toInt()
}
