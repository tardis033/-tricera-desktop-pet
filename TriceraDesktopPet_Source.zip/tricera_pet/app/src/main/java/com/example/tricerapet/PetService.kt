package com.example.tricerapet

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.ImageView
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

class PetService : Service() {
    companion object {
        const val PREFS = "tricera_prefs"
        const val ACTION_SHOW = "com.example.tricerapet.SHOW"
        const val ACTION_HIDE = "com.example.tricerapet.HIDE"
        const val ACTION_STOP = "com.example.tricerapet.STOP"
        const val ACTION_SETTINGS = "com.example.tricerapet.SETTINGS"
        private const val CHANNEL = "tricera_pet_channel"
        fun notifySettingsChanged(context: Context) {
            val i = Intent(context, PetService::class.java).setAction(ACTION_SETTINGS)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
    private lateinit var wm: WindowManager
    private var petView: PetView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastTouch = System.currentTimeMillis()
    private val idleCheck = object : Runnable { override fun run() { petView?.refreshIdle(); handler.postDelayed(this, 5000) } }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        startForeground(41, notification())
        handler.post(idleCheck)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> removePet()
            ACTION_STOP -> { removePet(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            ACTION_SETTINGS -> petView?.applySettings()
            else -> if (Settings.canDrawOverlays(this)) showPet()
        }
        return START_STICKY
    }
    private fun showPet() {
        if (petView != null) { petView?.visibility = View.VISIBLE; petView?.applySettings(); return }
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val size = (prefs.getInt("size", 150) * resources.displayMetrics.density).toInt()
        val p = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 30); y = prefs.getInt("y", 300)
        }
        val view = PetView(this)
        petView = view; params = p
        try { wm.addView(view, p); view.applySettings() } catch (_: Exception) { petView = null; params = null }
    }
    private fun removePet() {
        petView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        petView = null; params = null
    }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); removePet(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "特里塞拉桌面宠物", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val hide = PendingIntent.getService(this, 2, Intent(this, PetService::class.java).setAction(ACTION_HIDE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("特里塞拉正在陪伴你").setContentText("点击打开设置；可从通知隐藏宠物")
            .setContentIntent(open).setOngoing(true).addAction(Notification.Action.Builder(null, "隐藏", hide).build()).build()
    }

    inner class PetView(context: Context) : ImageView(context) {
        private val prefs get() = getSharedPreferences(PREFS, MODE_PRIVATE)
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0; private var moved = false
        private var idle = false
        private var animator: ValueAnimator? = null
        init {
            setImageResource(R.drawable.tricera_original)
            scaleType = ScaleType.FIT_CENTER
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            contentDescription = "TRICERA 桌面宠物，点击互动，长按拖动"
        }
        fun refreshIdle() {
            val seconds = prefs.getInt("idle", 60).coerceAtLeast(15)
            val shouldIdle = System.currentTimeMillis() - lastTouch > seconds * 1000L
            if (shouldIdle != idle) {
                idle = shouldIdle
                animateState()
            }
        }

        private fun wake() {
            lastTouch = System.currentTimeMillis()
            if (idle && prefs.getBoolean("touchWake", true)) {
                idle = false
                animateState()
            }
        }

        fun applySettings() {
            val p = params ?: return
            val size = (prefs.getInt("size", 150) * resources.displayMetrics.density).toInt()
            p.width = size
            p.height = size
            alpha = prefs.getInt("alpha", 100).coerceIn(35, 100) / 100f
            try { wm.updateViewLayout(this, p) } catch (_: Exception) {}
            animateState()
            invalidate()
        }

        private fun animateState() {
            animator?.cancel()
            animator = null
            if (!prefs.getBoolean("animation", true)) {
                scaleX = 1f
                scaleY = 1f
                rotation = 0f
                return
            }
            if (idle) {
                // 安静休息：轻轻呼吸式缩放，持续循环，不移动桌面位置。
                animator = ValueAnimator.ofFloat(1f, 0.965f, 1f).apply {
                    duration = 2600L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = DecelerateInterpolator()
                    addUpdateListener {
                        val scale = it.animatedValue as Float
                        scaleX = scale
                        scaleY = scale
                    }
                    start()
                }
            } else {
                // 被触碰或从休息状态恢复时，做一次轻快的弹跳回应。
                animator = ValueAnimator.ofFloat(1f, 1.10f, 0.96f, 1.035f, 1f).apply {
                    duration = 520L
                    interpolator = DecelerateInterpolator()
                    addUpdateListener {
                        val scale = it.animatedValue as Float
                        scaleX = scale
                        scaleY = scale
                    }
                    start()
                }
            }
        }
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            val p = params ?: return true
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = p.x; startY = p.y; moved = false; return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) { p.x = (startX + dx).coerceAtLeast(0); p.y = (startY + dy).coerceAtLeast(0); try { wm.updateViewLayout(this, p) } catch (_: Exception) {} }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
                    if (!moved) {
                        val wasIdle = idle
                        wake()
                        performClick()
                        if (!wasIdle || !prefs.getBoolean("touchWake", true)) animateState()
                    } else if (idle && prefs.getBoolean("touchWake", true)) {
                        wake()
                    }
                    return true
                }
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
