package com.example.tricerapet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFFFFF8F2.toInt())
        }
        root.addView(TextView(this).apply {
            text = "TRICERA 桌面宠物"
            textSize = 25f
            setTextColor(0xFF30221E.toInt())
        }, match())
        root.addView(TextView(this).apply {
            text = "原图角色 · 常驻陪伴 · 触摸互动 · 休息反应"
            textSize = 15f
            setTextColor(0xFF74645D.toInt())
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad * 2)
        }, match())
        root.addView(actionButton("显示桌面宠物") { startPet() }, match())
        root.addView(actionButton("个性化设置") { startActivity(Intent(this, SettingsActivity::class.java)) }, match())
        root.addView(actionButton("隐藏桌面宠物") { sendPetAction(PetService.ACTION_HIDE) }, match())
        root.addView(TextView(this).apply {
            text = "首次使用需允许“显示在其他应用上层”。\n角色图只用于本地显示；悬浮权限可随时在系统设置中关闭。"
            textSize = 13f
            setTextColor(0xFF74645D.toInt())
            setPadding(0, pad * 2, 0, 0)
        }, match())
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 30)
        }
    }

    private fun startPet() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "请允许显示在其他应用上层，然后返回并再次点击显示", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, PetService::class.java).setAction(PetService.ACTION_SHOW)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "特里塞拉已出现", Toast.LENGTH_SHORT).show()
    }

    private fun sendPetAction(action: String) {
        if (!Settings.canDrawOverlays(this)) return
        val i = Intent(this, PetService::class.java).setAction(action)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
