# TRICERA Desktop Pet (Android starter project)

An Android Studio project for a simple floating desktop companion using the user's supplied TRICERA image. The character artwork itself is not redrawn; the app crops away the screenshot background and makes only the outside white background transparent so the character can float over other apps.

## Included
- Floating overlay above other apps
- Tap response (small scale/bounce reaction)
- Drag to reposition; position is saved locally
- Idle/rest state after a configurable delay; touching wakes it
- Size, opacity, idle delay and animation settings
- Persistent foreground notification with a hide action

No feeding or play features are included.

## Build
1. Open this folder in Android Studio (current stable version).
2. Allow Android Studio to install the Android SDK platform/build tools for API 35 if prompted.
3. Build > Build APK(s).
4. Install the generated debug APK on the Galaxy S26 Ultra.
5. Open the app, grant **Display over other apps**, then tap **Show desktop pet**.

## Notes
- This environment did not have Android SDK/Gradle installed, so an APK could not be built here; this is the source project.
- Android may stop background services under battery restrictions. If the pet disappears, allow background activity for the app in system settings.
- The notification is used so Android can keep the companion service running. You can hide the pet from the notification or close it through Android settings.
- The app does not request internet access.
